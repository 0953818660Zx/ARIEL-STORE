export const PRODUCTS = [
  { id: "delta-pro", title: "Delta Pro Access", category: "featured", price: 299, stock: 18 },
  { id: "phantom-core", title: "Phantom Core", category: "premium", price: 499, stock: 9 },
  { id: "orbit-lite", title: "Orbit Lite", category: "starter", price: 149, stock: 42 },
  { id: "night-ops", title: "Night Ops Toolkit", category: "featured", price: 349, stock: 26 },
  { id: "gbox-105", title: "GBOX 105 License", category: "license", price: 899, stock: 7 },
  { id: "redline", title: "Redline Utility", category: "starter", price: 199, stock: 31 },
  { id: "vault-pass", title: "Vault Pass Monthly", category: "subscription", price: 259, stock: 999 },
  { id: "starter-kit", title: "Starter Kit 01", category: "starter", price: 99, stock: 56 },
] as const;
