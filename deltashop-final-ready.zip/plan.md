# DeltaShop Commerce — แผนการพัฒนา

## ขอบเขต
พัฒนาร้านค้าออนไลน์ใหม่ที่มีประสบการณ์ใช้งานใกล้เคียงเว็บไซต์อ้างอิงในส่วนที่มองเห็นได้จากหน้าสาธารณะ: แบรนด์โทนดำ–แดง, เมนูร้านค้า, สินค้า, ระบบสมาชิก, ตะกร้า, คำสั่งซื้อ และแดชบอร์ดผู้ดูแล โดยใช้ชื่อและข้อมูลจำลองของโปรเจกต์นี้เอง ไม่คัดลอกบัญชี ข้อมูลส่วนตัว CAPTCHA/Cloudflare หรือโค้ดภายในของเว็บอ้างอิง

## สถาปัตยกรรม
- Frontend: React + Vite + TypeScript + Wouter + Tailwind CSS + Lucide
- Backend: Express + tRPC + Drizzle ORM
- Data: Managed MySQL ผ่าน DATABASE_URL; มี fallback mock data สำหรับ Preview ที่ยังไม่มีข้อมูล
- Authentication: Manus OAuth ของ starter และสิทธิ์ `users.role` สำหรับ admin
- Assets: CSS-based product art และ placeholder ที่ปลอดภัย; อัปโหลดสินค้าในเฟสถัดไปผ่าน Storage

## หน้าหลัก
- `/` หน้าร้าน: hero, สินค้าเด่น, หมวดหมู่, จุดเด่นบริการ, ขั้นตอนสั่งซื้อ
- `/products` แคตตาล็อก: ค้นหา กรองหมวดหมู่ เรียงราคา/ความนิยม
- `/product/:id` รายละเอียดสินค้าและเพิ่มลงตะกร้า
- `/cart` ตะกร้าและสรุปยอด
- `/login` หน้าเข้าสู่ระบบ/สมัครสมาชิกแบบ UI พร้อมจุดต่อ OAuth
- `/account` โปรไฟล์และประวัติคำสั่งซื้อ

## แผงแอดมิน
- `/admin` KPI ยอดขาย คำสั่งซื้อ ลูกค้า สต็อก และกราฟกิจกรรม
- `/admin/products` จัดการสินค้า หมวดหมู่ ราคา สต็อก และสถานะ
- `/admin/orders` ตรวจสอบคำสั่งซื้อและเปลี่ยนสถานะ
- `/admin/customers` รายชื่อลูกค้าและสถานะ
- `/admin/settings` ตั้งค่าร้านและช่องทางติดต่อ

## Design System
- Design movement: cyber-commerce / dark utility dashboard
- Core principles: อ่านง่ายบนพื้นมืด, สีแดงใช้เป็น action signal, information density สูงแต่มีลำดับ, responsive-first
- Color philosophy: obsidian เป็นฐานความน่าเชื่อถือ, crimson เป็นสีประจำแบรนด์และ CTA, muted gray ลดความล้าของสายตา
- Layout paradigm: แถบประกาศและ header แบบ full-bleed ต่อด้วย content rail; dashboard ใช้ sidebar utility rail
- Signature elements: เส้นขอบแดงบาง, glass card ดำโปร่ง, red glow ที่ active state
- Interaction: hover lift, focus ring สีแดง, toast สำหรับ action, drawer/cart feedback
- Animation: fade-up เบา ๆ, glow เฉพาะ CTA, หลีกเลี่ยง motion หนัก
- Typography: system sans ที่อ่านง่ายบนไทย, weight 500/700 แยก label และ heading
- Brand essence: ร้านดิจิทัลที่ส่งมอบของไวและชัดเจนสำหรับผู้ใช้ที่ต้องการความสะดวก — คม, เร็ว, โปร่งใส
- Brand voice: สั้น ตรง และมั่นใจ เช่น “เลือกของที่ใช่ แล้วรับโค้ดทันที” / “ทุกคำสั่งซื้อมีสถานะให้ติดตาม”
- Wordmark: ตัวอักษร DS ในกรอบวงกลมแดง ใช้เป็นสัญลักษณ์แทน DeltaShop
- Signature brand color: `#E50918`

## โครงสร้างโค้ด
- `client/src/pages`: หน้า Store, Auth, Account และ Admin
- `client/src/lib/store.tsx`: catalog, cart state, pricing helpers และ mock persistence
- `server/routers.ts`: system/auth + จุดต่อ API สินค้า/คำสั่งซื้อ/admin
- `drizzle/schema.ts`: users, products, categories, orders, order items, coupons, banners, audit logs
- `public/manus-routes.json`: route manifest สำหรับหน้าเว็บทั้งหมด

## Build workflow
1. สร้างหน้าร้านและแผงแอดมินด้วย mock catalog เพื่อให้ Preview เห็นผลทันที
2. เพิ่ม schema/migration และ router สำหรับ MySQL
3. ตรวจ TypeScript, build และ health endpoint
4. เริ่ม Preview service และตรวจ route manifest
5. บันทึก checkpoint เมื่อทุกเส้นทางหลัก build ผ่าน
