export default {
  logoUrl: "https://dummyimage.com/128x128/09090b/e50918.png&text=DS",
};
