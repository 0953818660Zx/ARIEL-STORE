import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { StoreProvider } from "./lib/store";
import Home from "./pages/Home";
import Products from "./pages/Products";
import Cart from "./pages/Cart";
import Admin from "./pages/Admin";
import Auth from "./pages/Auth";
import Account from "./pages/Account";
import ProductDetail from "./pages/ProductDetail";
import Checkout from "./pages/Checkout";
import Info from "./pages/Info";
import Topup from "./pages/Topup";
import { Route, Switch } from "wouter";

function Router() {
  return <Switch>
    <Route path="/" component={Home} />
    <Route path="/products" component={Products} />
    <Route path="/product/:id" component={ProductDetail} />
    <Route path="/cart" component={Cart} />
    <Route path="/checkout" component={Checkout} />
    <Route path="/how" component={Info} />
    <Route path="/contact" component={Info} />
    <Route path="/login" component={Auth} />
    <Route path="/account" component={Account} />
    <Route path="/topup" component={Topup} />
    <Route path="/admin/:section?" component={Admin} />
    <Route component={Home} />
  </Switch>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="dark"><TooltipProvider><Toaster /><StoreProvider><Router /></StoreProvider></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
