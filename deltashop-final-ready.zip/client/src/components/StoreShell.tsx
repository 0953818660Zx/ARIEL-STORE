import { ArrowRight, Check, ChevronDown, Clock3, Coins, Eye, Headphones, LogIn, LogOut, Menu, Search, Settings, ShieldCheck, ShoppingCart, Sparkles, UserRound, X, Zap } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Product, useStore, formatTHB } from "@/lib/store";
import { useTheme } from "@/contexts/ThemeContext";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { WalletCards } from "lucide-react";

export function BrandMark({ compact = false }: { compact?: boolean }) {
  const { settings } = useTheme();
  return <div className="brand-mark"><span className={settings.logoUrl ? "has-logo" : ""}>{settings.logoUrl ? <img src={settings.logoUrl} alt={settings.storeName} /> : "DS"}</span>{!compact && <div><b>{settings.storeName}</b><small>STORE</small></div>}</div>;
}

export function SiteHeader() {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  const { user, logout } = useAuth();
  const accountSummary = trpc.account.summary.useQuery(undefined, { enabled: Boolean(user), refetchOnWindowFocus: true });
  const nav = [{ href: "/", label: "หน้าแรก" }, { href: "/products", label: "สินค้าทั้งหมด" }, { href: "/account", label: "ประวัติการสั่งซื้อ" }, { href: "/how", label: "วิธีสั่งซื้อ" }, { href: "/contact", label: "ติดต่อเรา" }];
  const closeMenu = () => setOpen(false);
  const handleLogout = () => { closeMenu(); void logout(); };
  return <>
    <div className="announcement"><Sparkles size={14} /> โปรโมชันเปิดร้านใหม่ ลดสูงสุด 30% วันนี้เท่านั้น <ArrowRight size={13} /></div>
    <header className="site-header"><div className="site-header-inner">
      <button type="button" className="mobile-toggle" onClick={() => setOpen(value => !value)} aria-label={open ? "ปิดเมนู" : "เปิดเมนู"} aria-expanded={open}>{open ? <X /> : <Menu />}</button>
      <Link href="/" className="brand-link" onClick={closeMenu}><BrandMark /></Link>
      <nav className={`main-nav ${open ? "is-open" : ""}`}>{nav.map(item => <Link key={item.href} href={item.href} className={location === item.href ? "active" : ""} onClick={closeMenu}>{item.label}</Link>)}{user && <Link href="/topup" className="mobile-auth-link" onClick={closeMenu}><WalletCards size={15} /> เติมเงิน</Link>}{user?.role === "admin" && <Link href="/admin" className="mobile-auth-link" onClick={closeMenu}><Settings size={15} /> แผงควบคุมแอดมิน</Link>}{user ? <button type="button" className="mobile-auth-link mobile-auth-button" onClick={handleLogout}><LogOut size={15} /> ออกจากระบบ</button> : <Link href="/login" className="mobile-auth-link" onClick={closeMenu}><LogIn size={15} /> เข้าสู่ระบบ</Link>}</nav>
      <div className="header-actions"><Link href="/products" className="icon-action header-search-action" aria-label="ค้นหา"><Search size={19} /></Link>{user && <Link href="/account" className="header-balance-pill" title="ดูยอดเงินของฉัน"><Coins size={15} /><span>{accountSummary.isLoading ? "..." : formatTHB(accountSummary.data?.balance ?? 0)}</span></Link>}<Link href={user ? "/account#profile" : "/login"} className="icon-action user-action profile-header-action" aria-label={user ? "โปรไฟล์ของฉัน" : "เข้าสู่ระบบ"}>{user?.avatarUrl ? <img className="header-profile-image" src={user.avatarUrl} alt="รูปโปรไฟล์" /> : <UserRound size={19} />}</Link></div>
    </div></header>
  </>;
}

export function SiteFooter() {
  const { settings } = useTheme();
  return <footer className="site-footer" id="contact"><div className="footer-grid"><div><BrandMark /><p className="footer-copy">ร้านดิจิทัลที่ออกแบบให้การเลือกซื้อและรับสินค้าเป็นเรื่องง่าย โปร่งใส และตรวจสอบได้</p><div className="footer-social">{settings.facebookUrl && <a href={settings.facebookUrl} target="_blank" rel="noreferrer" aria-label="ติดต่อผ่าน Facebook" title="Facebook">FB</a>}{settings.discordUrl && <a href={settings.discordUrl} target="_blank" rel="noreferrer" aria-label="เข้าร่วม Discord" title="Discord">DIS</a>}{settings.lineUrl && <a href={settings.lineUrl} target="_blank" rel="noreferrer" aria-label="แชตผ่าน LINE" title="LINE">LINE</a>}{settings.tiktokUrl && <a href={settings.tiktokUrl} target="_blank" rel="noreferrer" aria-label="ติดตาม TikTok" title="TikTok">TT</a>}</div></div><div><h4>ร้านค้า</h4><Link href="/products">สินค้าทั้งหมด</Link><Link href="/products?category=featured">สินค้าขายดี</Link><Link href="/products?category=starter">สำหรับผู้เริ่มต้น</Link></div><div><h4>ช่วยเหลือ</h4><Link href="/account">บัญชีของฉัน</Link><Link href="/how">วิธีสั่งซื้อ</Link><Link href="/contact">ติดต่อทีมงาน</Link></div><div><h4>ติดต่อเรา</h4><p>จันทร์–อาทิตย์ 09:00–22:00</p><p>support@deltashop.local</p><Link href="/contact" className="footer-contact-link">ดูช่องทางติดต่อทั้งหมด <ArrowRight size={13} /></Link></div></div><div className="footer-bottom"><span>© 2026 {settings.storeName}</span><span>บริการด้วยความใส่ใจ • ปลอดภัย • ตรวจสอบได้</span></div></footer>;
}

const toneClass: Record<Product["tone"], string> = { red: "art-red", violet: "art-violet", cyan: "art-cyan", amber: "art-amber", green: "art-green" };
export function ProductArt({ product, large = false }: { product: Product; large?: boolean }) {
  const { settings } = useTheme();
  const imageUrl = product.imageUrl || settings.productImageUrl;
  return <div className={`product-art ${toneClass[product.tone]} ${large ? "product-art-large" : ""} ${imageUrl ? "has-product-image" : ""}`}><div className="art-grid" /><div className="art-orb" />{imageUrl && <img className="product-image-link" src={imageUrl} alt={product.title} />}<div className="art-lines" /><strong>{product.tag}</strong><span className="art-code">DS / {product.id.slice(0, 4).toUpperCase()}</span></div>;
}

export function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useStore();
  const [, setLocation] = useLocation();
  const buyNow = (event: React.MouseEvent<HTMLButtonElement>) => { event.preventDefault(); if ((product.options?.length ?? 0) > 1) { setLocation(`/product/${product.id}`); return; } addToCart(product); setLocation("/checkout"); };
  return <article className="product-card"><Link href={`/product/${product.id}`}><div className="card-art-wrap"><ProductArt product={product} />{product.badge && <span className="product-badge">{product.badge}</span>}<span className="quick-view">ดูรายละเอียด <ArrowRight size={14} /></span></div></Link><div className="product-card-body"><div className="product-meta"><span>{product.categoryLabel}</span><span>★ {product.rating}</span></div><div className="product-stats"><span><b>สต็อก</b> {product.stock}</span><span><b>ผู้ใช้งาน</b> {Math.max(1, Math.round(product.sold * .72))}</span><span><b>ขายแล้ว</b> {product.sold}</span></div><Link href={`/product/${product.id}`}><h3>{product.title}</h3></Link><Link href={`/product/${product.id}`} className="product-detail-button"><Eye size={17} /> ดูรายละเอียด</Link><div className="product-buy"><div><strong>{formatTHB(product.price)}</strong><small>{product.options?.length ? `${product.options.length} แพ็กเกจ` : "แพ็กเกจมาตรฐาน"}</small></div><button type="button" className="add-btn buy-now-btn" onClick={buyNow} disabled={product.stock <= 0} aria-label={product.stock > 0 ? `ซื้อ ${product.title} ทันที` : `${product.title} หมดสต็อก`}><ShoppingCart size={16} /> <span>{product.stock > 0 ? "ซื้อทันที" : "หมดสต็อก"}</span></button></div></div></article>;
}

export function ServiceStrip() {
  const items = [{ icon: Zap, title: "ส่งมอบรวดเร็ว", text: "รับสินค้าอัตโนมัติ" }, { icon: ShieldCheck, title: "ปลอดภัยและชัดเจน", text: "มีประวัติให้ตรวจสอบ" }, { icon: Headphones, title: "ทีมงานพร้อมช่วย", text: "ซัพพอร์ตทุกวัน" }, { icon: Clock3, title: "เปิดบริการทุกวัน", text: "09:00 – 22:00 น." }];
  return <div className="service-strip">{items.map(({ icon: Icon, title, text }) => <div className="service-item" key={title}><Icon size={19} /><div><b>{title}</b><span>{text}</span></div></div>)}</div>;
}

export function SectionHeading({ eyebrow, title, action }: { eyebrow: string; title: string; action?: React.ReactNode }) { return <div className="section-heading"><div><span className="eyebrow">{eyebrow}</span><h2>{title}</h2></div>{action}</div>; }

export function MobileSelect({ value, onChange }: { value: string; onChange: (value: string) => void }) { return <div className="mobile-select"><select value={value} onChange={event => onChange(event.target.value)}><option value="all">ทุกหมวดหมู่</option><option value="featured">โปรแกรมช่วยเล่น</option><option value="starter">เริ่มต้น</option><option value="premium">พรีเมียม</option><option value="license">ใบรับรอง</option><option value="subscription">สมาชิก</option></select><ChevronDown size={16} /></div>; }
