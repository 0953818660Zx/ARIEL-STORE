import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { trpc } from "@/lib/trpc";

export type ProductOption = { id: number; label: string; price: number; stock: number };

export type Product = {
  id: string;
  title: string;
  category: string;
  categoryLabel: string;
  price: number;
  compareAt: number;
  stock: number;
  rating: number;
  sold: number;
  badge?: string;
  tone: "red" | "violet" | "cyan" | "amber" | "green";
  description: string;
  tag: string;
  imageUrl?: string;
  options?: ProductOption[];
  selectedOption?: ProductOption;
};

export const PRODUCTS: Product[] = [
  { id: "delta-pro", title: "Delta Pro Access", category: "featured", categoryLabel: "โปรแกรมช่วยเล่น", price: 299, compareAt: 399, stock: 18, rating: 4.9, sold: 482, badge: "ขายดี", tone: "red", tag: "D-PRO", description: "แพ็กเกจใช้งานระดับโปร พร้อมระบบจัดการคีย์ที่ใช้งานง่ายและรองรับการส่งมอบอัตโนมัติ", },
  { id: "phantom-core", title: "Phantom Core", category: "premium", categoryLabel: "พรีเมียม", price: 499, compareAt: 599, stock: 9, rating: 4.8, sold: 237, badge: "พรีเมียม", tone: "violet", tag: "PH", description: "ชุดเครื่องมือดิจิทัลสำหรับผู้ใช้ที่ต้องการความเร็ว ความเสถียร และแดชบอร์ดจัดการในชุดเดียว", },
  { id: "orbit-lite", title: "Orbit Lite", category: "starter", categoryLabel: "เริ่มต้น", price: 149, compareAt: 199, stock: 42, rating: 4.7, sold: 691, badge: "คุ้มค่า", tone: "cyan", tag: "ORBIT", description: "ตัวเลือกเริ่มต้นที่ตั้งค่าได้เร็ว เหมาะสำหรับผู้ที่ต้องการทดลองใช้งานโดยไม่ผูกมัด", },
  { id: "night-ops", title: "Night Ops Toolkit", category: "featured", categoryLabel: "โปรแกรมช่วยเล่น", price: 349, compareAt: 449, stock: 26, rating: 4.9, sold: 318, tone: "amber", tag: "NIGHT", description: "เครื่องมือจัดการโปรไฟล์และการตั้งค่าที่ช่วยให้ workflow ของคุณเป็นระเบียบมากขึ้น", },
  { id: "gbox-105", title: "GBOX 105 License", category: "license", categoryLabel: "ใบรับรอง", price: 899, compareAt: 999, stock: 7, rating: 4.8, sold: 104, badge: "จำนวนจำกัด", tone: "green", tag: "GBOX", description: "ใบรับรองดิจิทัลพร้อมระบบตรวจสอบสถานะและประวัติการสั่งซื้อจากบัญชีของคุณ", },
  { id: "redline", title: "Redline Utility", category: "starter", categoryLabel: "เริ่มต้น", price: 199, compareAt: 249, stock: 31, rating: 4.6, sold: 384, tone: "red", tag: "RED", description: "ยูทิลิตี้ขนาดเล็กที่ติดตั้งง่ายและมีคู่มือภาษาไทยสำหรับผู้เริ่มต้น", },
  { id: "vault-pass", title: "Vault Pass Monthly", category: "subscription", categoryLabel: "สมาชิก", price: 259, compareAt: 299, stock: 999, rating: 4.7, sold: 812, badge: "สมาชิก", tone: "violet", tag: "VAULT", description: "สิทธิ์เข้าถึงคอนเทนต์และข้อเสนอพิเศษรายเดือน พร้อมประวัติการชำระเงินที่ตรวจสอบได้", },
  { id: "starter-kit", title: "Starter Kit 01", category: "starter", categoryLabel: "เริ่มต้น", price: 99, compareAt: 129, stock: 56, rating: 4.5, sold: 1204, tone: "cyan", tag: "KIT 01", description: "ชุดเริ่มต้นราคาประหยัดสำหรับการทดลองระบบและทำความคุ้นเคยกับหน้าร้าน", },
];

export type CartLine = { product: Product; quantity: number };
const cartKey = (product: Product) => `${product.id}:${product.selectedOption?.id ?? "base"}`;

type StoreContextValue = {
  products: Product[];
  cart: CartLine[];
  cartCount: number;
  subtotal: number;
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string, quantity?: number) => void;
  setQuantity: (productId: string, quantity: number, optionId?: number) => void;
  clearCart: () => void;
};

const StoreContext = createContext<StoreContextValue | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const productsQuery = trpc.catalog.products.useQuery();
  const products = (productsQuery.data ?? PRODUCTS) as Product[];
  const [cart, setCart] = useState<CartLine[]>(() => {
    try { return JSON.parse(localStorage.getItem("deltashop-cart") ?? "[]"); } catch { return []; }
  });

  useEffect(() => { localStorage.setItem("deltashop-cart", JSON.stringify(cart)); }, [cart]);
  useEffect(() => {
    if (!productsQuery.data) return;
    setCart(current => current.flatMap(line => {
      const latest = products.find(product => product.id === line.product.id);
      if (!latest || latest.stock <= 0) return [];
      const latestOption = line.product.selectedOption ? latest.options?.find(option => option.id === line.product.selectedOption?.id) : undefined; const refreshed = latestOption ? { ...latest, price: latestOption.price, stock: latestOption.stock, selectedOption: latestOption } : latest; return refreshed.stock > 0 ? [{ product: refreshed, quantity: Math.min(line.quantity, refreshed.stock) }] : [];
    }));
  }, [productsQuery.data, products]);

  const value = useMemo<StoreContextValue>(() => ({
    products,
    cart,
    cartCount: cart.reduce((sum, line) => sum + line.quantity, 0),
    subtotal: cart.reduce((sum, line) => sum + line.product.price * line.quantity, 0),
    addToCart: product => setCart(current => {
      const existing = current.find(line => cartKey(line.product) === cartKey(product));
      if (existing && existing.quantity >= product.stock) return current;
      return existing ? current.map(line => cartKey(line.product) === cartKey(product) ? { ...line, quantity: Math.min(product.stock, line.quantity + 1) } : line) : [...current, { product, quantity: 1 }];
    }),
    removeFromCart: (productId, optionId) => setCart(current => current.filter(line => !(line.product.id === productId && (optionId === undefined ? true : line.product.selectedOption?.id === optionId)))),
    setQuantity: (productId, quantity, optionId) => setCart(current => quantity <= 0 ? current.filter(line => !(line.product.id === productId && (optionId === undefined ? true : line.product.selectedOption?.id === optionId))) : current.map(line => line.product.id === productId && (optionId === undefined ? true : line.product.selectedOption?.id === optionId) ? { ...line, quantity: Math.min(line.product.stock, quantity) } : line)),
    clearCart: () => setCart([]),
  }), [products, cart]);

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) throw new Error("useStore must be used within StoreProvider");
  return context;
}

export function formatTHB(value: number) {
  return new Intl.NumberFormat("th-TH", { style: "currency", currency: "THB", maximumFractionDigits: 0 }).format(value);
}
