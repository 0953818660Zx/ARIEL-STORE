import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import { trpc } from "@/lib/trpc";

export type StoreSettings = {
  storeName: string;
  logoUrl: string;
  productImageUrl: string;
  heroTitle: string;
  heroDescription: string;
  lineUrl: string;
  tiktokUrl: string;
  facebookUrl: string;
  discordUrl: string;
  primaryColor: string;
  accentColor: string;
  theme: "light" | "dark";
  snowEnabled: boolean;
  borderEnabled: boolean;
  borderColor: string;
};

export const DEFAULT_STORE_SETTINGS: StoreSettings = {
  storeName: "DeltaShop Commerce",
  logoUrl: "",
  productImageUrl: "",
  heroTitle: "เลือกของที่ใช่\nแล้วรับโค้ดทันที",
  heroDescription: "รวมสินค้าและบริการดิจิทัลที่คัดมาให้แล้ว ใช้งานง่าย ส่งมอบไว พร้อมดูสถานะคำสั่งซื้อได้ทุกเวลา",
  lineUrl: "",
  tiktokUrl: "",
  facebookUrl: "",
  discordUrl: "",
  primaryColor: "#e50918",
  accentColor: "#ff2636",
  theme: "dark",
  snowEnabled: false,
  borderEnabled: true,
  borderColor: "#e50918",
};

type ThemeContextType = { settings: StoreSettings; setSettings: React.Dispatch<React.SetStateAction<StoreSettings>>; theme: "light" | "dark"; toggleTheme: () => void };
const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: React.ReactNode; defaultTheme?: "light" | "dark" }) {
  const [settings, setSettings] = useState<StoreSettings>(() => {
    try { return { ...DEFAULT_STORE_SETTINGS, ...JSON.parse(localStorage.getItem("deltashop-settings") ?? "{}") }; } catch { return DEFAULT_STORE_SETTINGS; }
  });
  const remote = trpc.store.settings.useQuery(undefined, { staleTime: 30_000, retry: false });

  useEffect(() => { if (remote.data) setSettings(current => ({ ...current, ...remote.data })); }, [remote.data]);
  useEffect(() => {
    const root = document.documentElement;
    root.dataset.storeTheme = settings.theme;
    root.dataset.borderEnabled = String(settings.borderEnabled);
    root.style.setProperty("--red", settings.primaryColor);
    root.style.setProperty("--red-bright", settings.accentColor);
    root.style.setProperty("--store-border-color", settings.borderColor);
    root.style.setProperty("--store-logo-url", settings.logoUrl ? `url(${JSON.stringify(settings.logoUrl)})` : "none");
    document.title = settings.storeName;
    localStorage.setItem("deltashop-settings", JSON.stringify(settings));
  }, [settings]);

  const snow = useMemo(() => settings.snowEnabled ? <div className="store-snow" aria-hidden="true">{Array.from({ length: 28 }, (_, index) => <i key={index} style={{ left: `${(index * 37) % 100}%`, animationDelay: `${(index % 11) * -0.7}s`, animationDuration: `${5 + (index % 7)}s` }}>✦</i>)}</div> : null, [settings.snowEnabled]);
  const toggleTheme = () => setSettings(current => ({ ...current, theme: current.theme === "dark" ? "light" : "dark" }));
  return <ThemeContext.Provider value={{ settings, setSettings, theme: settings.theme, toggleTheme }}>{snow}{children}</ThemeContext.Provider>;
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) throw new Error("useTheme must be used within ThemeProvider");
  return context;
}
