import { ArrowRight, Check, ClipboardList, Coins, KeyRound, LogIn, LogOut, PackageCheck, Save, UserRound } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { formatTHB } from "@/lib/store";
import { trpc } from "@/lib/trpc";
import { SiteFooter, SiteHeader } from "@/components/StoreShell";

export default function Account() {
  const { user, loading, logout, refresh } = useAuth();
  const summary = trpc.account.summary.useQuery(undefined, { enabled: Boolean(user) });
  const [nameDraft, setNameDraft] = useState("");
  const [avatarDraft, setAvatarDraft] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [profileMessage, setProfileMessage] = useState("");
  const [passwordMessage, setPasswordMessage] = useState("");

  useEffect(() => {
    if (user) { setNameDraft(user.name ?? ""); setAvatarDraft(user.avatarUrl ?? ""); }
  }, [user?.id, user?.name, user?.avatarUrl]);

  const updateProfile = trpc.account.updateProfile.useMutation({
    onSuccess: async result => {
      setProfileMessage(`บันทึกชื่อ “${result.name}” แล้ว`);
      await refresh();
    },
  });
  const changePassword = trpc.account.changePassword.useMutation({
    onSuccess: async () => {
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      setPasswordMessage("เปลี่ยนรหัสผ่านเรียบร้อยแล้ว");
      await refresh();
    },
  });

  if (loading) return <div className="loading-screen">กำลังโหลดบัญชี...</div>;
  if (!user) return <div className="store-page"><SiteHeader /><main className="account-empty container"><div className="empty-account-icon"><UserRound size={32} /></div><span className="eyebrow">MEMBER AREA</span><h1>เข้าสู่ระบบเพื่อดูบัญชีของคุณ</h1><p>จัดการคำสั่งซื้อ ประวัติการซื้อ และข้อมูลส่วนตัวได้จากหน้านี้</p><Link className="primary-btn" href="/login"><LogIn size={17} /> เข้าสู่ระบบ</Link></main><SiteFooter /></div>;

  const orders = summary.data?.orders ?? [];
  const balance = summary.data?.balance ?? 0;
  return <div className="store-page"><SiteHeader /><main className="account-page container"><div className="account-head"><div><span className="eyebrow">MEMBER / ACCOUNT</span><h1>สวัสดี, {user.name || "สมาชิก"}</h1><p>{user.email || "บัญชีสมาชิก DeltaShop"}</p></div><div className="account-head-actions"><Link className="outline-btn" href="#settings"><UserRound size={15} /> แก้ไขข้อมูลส่วนตัว</Link><div className="account-balance-badge" role="status" aria-label="ยอดเงินของฉัน"><Coins size={17} /><span><small>ยอดเงินของฉัน</small><strong>{summary.isLoading ? "กำลังโหลด..." : formatTHB(balance)}</strong></span></div><button className="logout-btn" onClick={() => logout()}><LogOut size={15} /> ออกจากระบบ</button></div></div><div className="account-grid"><aside className="account-menu"><div className="account-menu-head"><div className="profile-avatar">{user.avatarUrl ? <img src={user.avatarUrl} alt="รูปโปรไฟล์" /> : (user.name || "D").slice(0, 1)}</div><div><b>{user.name || "สมาชิก"}</b><span>{user.role === "reseller" ? "ตัวแทนจำหน่าย" : user.role === "admin" ? "ผู้ดูแลร้าน" : "สมาชิก DeltaShop"}</span></div></div><Link href="/account" className="active"><ClipboardList size={16} /> คำสั่งซื้อของฉัน</Link><Link href="#profile"><UserRound size={16} /> ข้อมูลส่วนตัว</Link><Link href="#settings"><KeyRound size={16} /> เปลี่ยนรหัสผ่าน</Link><button className="account-menu-logout" onClick={() => logout()}><LogOut size={16} /> ออกจากระบบ</button></aside><div className="account-main-column"><section className="account-orders"><div className="panel-head"><div><h2>ประวัติการสั่งซื้อ</h2><span>รายการและรหัสส่งมอบสินค้าของคุณ</span></div><span className="order-count">{orders.length} รายการ</span></div>{summary.isLoading ? <div className="loading-inline">กำลังโหลดประวัติการสั่งซื้อ...</div> : orders.length === 0 ? <div className="account-no-orders"><PackageCheck size={30} /><b>ยังไม่มีประวัติการสั่งซื้อ</b><span>เลือกสินค้าแล้วซื้อทันทีได้จากหน้าร้าน</span><Link className="primary-btn" href="/products">ไปเลือกสินค้า</Link></div> : orders.map(order => <div className="account-order" key={order.id}><div className="order-icon"><PackageCheck size={19} /></div><div><b>คำสั่งซื้อ {order.id}</b><span>{new Date(order.createdAt).toLocaleString("th-TH")} {order.deliveryCode ? `• รหัสรับสินค้า ${order.deliveryCode}` : ""}</span></div><strong>{formatTHB(order.total)}</strong><span className={`status-pill ${order.status === "delivered" ? "delivered" : order.status === "cancelled" ? "cancelled" : "paid"}`}>{order.status === "delivered" ? "ส่งมอบแล้ว" : order.status === "cancelled" ? "ยกเลิก" : "กำลังดำเนินการ"}</span><Link href={`/account#${order.id}`} aria-label={`ดูคำสั่งซื้อ ${order.id}`}><ArrowRight size={16} /></Link></div>)}</section><section className="account-settings panel" id="settings"><div className="account-settings-head"><div><span className="eyebrow">PROFILE / SECURITY</span><h2>ข้อมูลส่วนตัวและความปลอดภัย</h2><p>เปลี่ยนชื่อและรหัสผ่านได้ตลอดเวลา บัญชีของคุณจะถูกอัปเดตทันที</p></div></div><div className="account-settings-grid"><form id="profile" onSubmit={event => { event.preventDefault(); setProfileMessage(""); updateProfile.mutate({ name: nameDraft, avatarUrl: avatarDraft || undefined }); }}><h3><UserRound size={17} /> โปรไฟล์ของฉัน</h3><div className="profile-image-editor">{avatarDraft ? <img src={avatarDraft} alt="ตัวอย่างรูปโปรไฟล์" /> : <UserRound size={28} />}<span>รูปโปรไฟล์จะแสดงที่ปุ่มบัญชีและหน้า Account</span></div><label>ลิงก์รูปโปรไฟล์<input type="url" value={avatarDraft} onChange={event => setAvatarDraft(event.target.value)} placeholder="https://.../avatar.jpg" /></label><label>ชื่อใหม่<input value={nameDraft} onChange={event => setNameDraft(event.target.value)} maxLength={120} required placeholder="ชื่อที่ต้องการแสดง" /></label><button className="primary-btn" type="submit" disabled={updateProfile.isPending || !nameDraft.trim()}><Save size={16} /> {updateProfile.isPending ? "กำลังบันทึก..." : "บันทึกชื่อ"}</button>{profileMessage && <p className="form-success"><Check size={15} /> {profileMessage}</p>}{updateProfile.error && <p className="form-error">{updateProfile.error.message}</p>}</form><form onSubmit={event => { event.preventDefault(); setPasswordMessage(""); changePassword.mutate({ currentPassword, newPassword, confirmPassword }); }}><h3><KeyRound size={17} /> เปลี่ยนรหัสผ่าน</h3><label>รหัสผ่านเดิม<input type="password" value={currentPassword} onChange={event => setCurrentPassword(event.target.value)} autoComplete="current-password" required /></label><label>รหัสผ่านใหม่<input type="password" value={newPassword} onChange={event => setNewPassword(event.target.value)} minLength={8} autoComplete="new-password" required placeholder="อย่างน้อย 8 ตัวอักษร" /></label><label>ยืนยันรหัสผ่านใหม่<input type="password" value={confirmPassword} onChange={event => setConfirmPassword(event.target.value)} minLength={8} autoComplete="new-password" required /></label><button className="primary-btn" type="submit" disabled={changePassword.isPending || !currentPassword || !newPassword || !confirmPassword}><KeyRound size={16} /> {changePassword.isPending ? "กำลังเปลี่ยน..." : "เปลี่ยนรหัสผ่าน"}</button>{passwordMessage && <p className="form-success"><Check size={15} /> {passwordMessage}</p>}{changePassword.error && <p className="form-error">{changePassword.error.message}</p>}</form></div></section></div></div></main><SiteFooter /></div>;
}
