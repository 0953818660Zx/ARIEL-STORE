import { ArrowLeft, ArrowRight, Check, Clock3, Link2, Mail, MessageCircle, MessageSquare, Music2, ShoppingBag, ShieldCheck } from "lucide-react";
import { Link, useLocation, useRoute } from "wouter";
import { useTheme } from "@/contexts/ThemeContext";
import { SiteFooter, SiteHeader } from "@/components/StoreShell";

const socialChannels = [
  { key: "lineUrl", label: "LINE", title: "แชตผ่าน LINE", icon: MessageCircle },
  { key: "tiktokUrl", label: "TikTok", title: "ติดตาม TikTok", icon: Music2 },
  { key: "facebookUrl", label: "Facebook", title: "ติดต่อผ่าน Facebook", icon: Link2 },
  { key: "discordUrl", label: "Discord", title: "เข้าร่วม Discord", icon: MessageSquare },
] as const;

export default function Info() {
  const [, params] = useRoute("/:page");
  const [, setLocation] = useLocation();
  const { settings } = useTheme();
  const contact = params?.page === "contact";
  const configuredSocialChannels = socialChannels.filter(channel => Boolean(settings[channel.key]));

  return <div className="store-page"><SiteHeader /><main className="info-page container"><Link href="/" className="page-breadcrumb"><ArrowLeft size={15} /> กลับหน้าร้าน</Link><section className="info-hero"><span className="eyebrow">{contact ? "SUPPORT / CONTACT" : "GUIDE / HOW TO ORDER"}</span><h1>{contact ? "ติดต่อเรา" : "วิธีสั่งซื้อ"}</h1><p>{contact ? "ทีมงานพร้อมช่วยตรวจสอบคำสั่งซื้อ การชำระเงิน และการรับสินค้า" : "ซื้อสินค้าได้ง่าย รับโค้ดดิจิทัลทันทีหลังระบบตรวจสอบการชำระเงิน"}</p></section>{contact ? <div className="contact-grid"><a className="contact-card" href="mailto:support@deltashop.local"><Mail size={22} /><b>อีเมลทีมงาน</b><span>support@deltashop.local</span><small>ตอบกลับภายในเวลาทำการ</small></a>{configuredSocialChannels.map(({ key, label, title, icon: Icon }) => { const href = settings[key]; return <a className="contact-card contact-card-link" href={href} target="_blank" rel="noopener noreferrer" key={key} aria-label={title}><Icon size={22} /><b>{title}</b><span>{label}</span><small>{href}</small></a>; })}<div className="contact-card"><Clock3 size={22} /><b>เวลาทำการ</b><span>09:00–22:00 น.</span><small>ทุกวัน ไม่มีวันหยุด</small></div>{configuredSocialChannels.length === 0 && <div className="contact-card contact-card-muted"><Link2 size={22} /><b>ช่องทางออนไลน์</b><span>กำลังรอการตั้งค่า</span><small>แอดมินสามารถเพิ่มลิงก์ LINE, TikTok, Facebook และ Discord ได้จากหน้าตั้งค่าหน้าร้าน</small></div>}</div> : <section className="how-detail-grid">{[{ icon: ShoppingBag, no: "01", title: "เลือกสินค้า", text: "เปิดหน้าสินค้า อ่านรายละเอียด ราคา สต็อก และหมวดหมู่ แล้วกด ซื้อเลย" }, { icon: ShieldCheck, no: "02", title: "ชำระเงิน", text: "เข้าสู่ระบบ ตรวจสอบยอดรวม และทำตามช่องทางการชำระเงินที่ร้านกำหนด" }, { icon: Check, no: "03", title: "รับสินค้า", text: "หลังตรวจสอบการชำระเงิน ระบบจะแสดงรหัสส่งมอบทันทีในหน้าจอและประวัติการสั่งซื้อ" }].map(step => <div className="how-detail-card" key={step.no}><step.icon size={23} /><span>{step.no}</span><h2>{step.title}</h2><p>{step.text}</p></div>)}</section>}<div className="info-cta"><button type="button" className="primary-btn" onClick={() => setLocation("/products")}>{contact ? "ไปเลือกสินค้า" : "เริ่มเลือกสินค้า"} <ArrowRight size={17} /></button><Link href="/account" className="outline-btn">ประวัติการสั่งซื้อ</Link></div></main><SiteFooter /></div>;
}
