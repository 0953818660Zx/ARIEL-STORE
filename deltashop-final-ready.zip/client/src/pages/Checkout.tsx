import { ArrowLeft, CheckCircle2, Clipboard, Copy, LockKeyhole, ShieldCheck, Zap } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { formatTHB, useStore } from "@/lib/store";
import { trpc } from "@/lib/trpc";
import { ProductArt, SiteFooter, SiteHeader } from "@/components/StoreShell";

type Delivery = { orderNumber: string; deliveryCode: string; total: number };

export default function Checkout() {
  const { user, loading } = useAuth();
  const { cart, subtotal, clearCart } = useStore();
  const [note, setNote] = useState("");
  const [delivery, setDelivery] = useState<Delivery | null>(null);
  const [copied, setCopied] = useState(false);
  const createOrder = trpc.account.createOrder.useMutation({ onSuccess: result => { clearCart(); setDelivery({ orderNumber: result.orderNumber, deliveryCode: result.deliveryCode, total: result.total }); } });
  const copyCode = async () => { if (!delivery) return; await navigator.clipboard?.writeText(delivery.deliveryCode); setCopied(true); window.setTimeout(() => setCopied(false), 1800); };

  if (loading) return <div className="loading-screen">กำลังตรวจสอบบัญชี...</div>;
  if (!user) return <div className="store-page"><SiteHeader /><main className="account-empty container"><LockKeyhole size={38} className="empty-account-icon" /><span className="eyebrow">CHECKOUT / LOGIN REQUIRED</span><h1>เข้าสู่ระบบก่อนสั่งซื้อ</h1><p>เพื่อบันทึกคำสั่งซื้อและรับสินค้าอัตโนมัติ กรุณาเข้าสู่ระบบสมาชิก</p><Link href="/login" className="primary-btn">เข้าสู่ระบบ</Link></main><SiteFooter /></div>;
  if (delivery) return <div className="store-page"><SiteHeader /><main className="delivery-success container"><CheckCircle2 size={52} className="delivery-success-icon" /><span className="eyebrow">INSTANT DELIVERY / COMPLETE</span><h1>ซื้อสำเร็จ รับสินค้าได้เลย</h1><p>คำสั่งซื้อ <b>{delivery.orderNumber}</b> ถูกส่งมอบเข้าบัญชีของคุณแล้ว</p><section className="delivery-card"><div className="delivery-card-head"><div><span>รหัสรับสินค้า</span><strong>{delivery.deliveryCode}</strong></div><button onClick={copyCode}>{copied ? <CheckCircle2 size={16} /> : <Copy size={16} />} {copied ? "คัดลอกแล้ว" : "คัดลอกรหัส"}</button></div><div className="delivery-ready"><Zap size={17} /><span><b>พร้อมใช้งานทันที</b><small>ใช้รหัสนี้เพื่อเปิดดูสินค้าในบัญชีของคุณ</small></span></div><Link href="/account" className="primary-btn">ดูสินค้าในบัญชี <Clipboard size={16} /></Link></section><Link href="/products" className="text-btn">เลือกซื้อสินค้าเพิ่มเติม <ArrowLeft size={15} className="rotate-180" /></Link></main><SiteFooter /></div>;
  if (!cart.length) return <div className="store-page"><SiteHeader /><main className="empty-cart container"><h2>ยังไม่มีสินค้าในตะกร้า</h2><Link href="/products" className="primary-btn">กลับไปเลือกสินค้า</Link></main><SiteFooter /></div>;
  return <div className="store-page"><SiteHeader /><main className="checkout-page container"><div className="page-breadcrumb"><Link href="/cart"><ArrowLeft size={15} /> กลับไปตะกร้า</Link></div><div className="cart-heading"><div><span className="eyebrow">CHECKOUT / INSTANT DELIVERY</span><h1>ยืนยันแล้วรับสินค้าเลย</h1></div><span className="cart-secure"><ShieldCheck size={16} /> ส่งมอบอัตโนมัติ</span></div><div className="cart-layout"><section className="checkout-form panel"><div className="checkout-section"><h2>ข้อมูลสมาชิก</h2><div className="checkout-profile"><div className="profile-avatar">{(user.name || "D").slice(0, 1)}</div><div><b>{user.name || "สมาชิก DeltaShop"}</b><span>{user.email || "อีเมลบัญชีสมาชิก"}</span></div></div></div><div className="checkout-section"><h2>หมายเหตุคำสั่งซื้อ <span>ไม่บังคับ</span></h2><textarea value={note} onChange={event => setNote(event.target.value)} placeholder="ระบุข้อมูลเพิ่มเติมถึงทีมงาน..." /></div><div className="checkout-security"><Zap size={17} /><span>หลังยืนยัน ระบบจะบันทึกคำสั่งซื้อเป็นส่งมอบแล้วและแสดงรหัสรับสินค้าให้ทันที</span></div></section><aside className="summary-card"><h2>สรุปคำสั่งซื้อ</h2>{cart.map(line => <div className="checkout-item" key={`${line.product.id}:${line.product.selectedOption?.id ?? "base"}`}><ProductArt product={line.product} /><div><span>{line.product.title}{line.product.selectedOption ? ` / ${line.product.selectedOption.label}` : ""} × {line.quantity}</span><b>{formatTHB(line.product.price * line.quantity)}</b></div></div>)}<div className="summary-total"><span>ยอดสุทธิ</span><strong>{formatTHB(subtotal)}</strong></div><button className="primary-btn checkout-btn" disabled={createOrder.isPending} onClick={() => createOrder.mutate({ note, items: cart.map(line => ({ productId: line.product.id, productName: `${line.product.title}${line.product.selectedOption ? ` / ${line.product.selectedOption.label}` : ""}`, quantity: line.quantity, unitPrice: line.product.price })) })}>{createOrder.isPending ? "กำลังส่งมอบสินค้า..." : "ซื้อและรับสินค้าเลย"}</button>{createOrder.error && <p className="form-error">ไม่สามารถสร้างคำสั่งซื้อได้ กรุณาลองใหม่อีกครั้ง</p>}</aside></div></main><SiteFooter /></div>;
}
