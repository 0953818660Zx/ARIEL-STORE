import { Filter, Search, ShieldCheck, SlidersHorizontal, X } from "lucide-react";
import { useMemo, useState } from "react";
import { useSearch } from "wouter";
import { useStore } from "@/lib/store";
import { MobileSelect, ProductCard, SiteFooter, SiteHeader } from "@/components/StoreShell";

export default function Products() {
  const { products } = useStore();
  const search = useSearch();
  const initialCategory = new URLSearchParams(search).get("category") ?? "all";
  const [category, setCategory] = useState(initialCategory);
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("popular");
  const filtered = useMemo(() => products.filter(product => (category === "all" || product.category === category) && product.title.toLowerCase().includes(query.toLowerCase())), [products, category, query]);
  const sorted = [...filtered].sort((a, b) => sort === "price-low" ? a.price - b.price : sort === "price-high" ? b.price - a.price : b.sold - a.sold);
  return <div className="store-page"><SiteHeader /><main className="catalog-page"><div className="container"><div className="catalog-head"><div><span className="eyebrow">DELTA STORE / CATALOG</span><h1>สินค้าทั้งหมด</h1><p>เลือกดูสินค้าดิจิทัลทั้งหมดที่พร้อมส่งมอบให้คุณ</p></div><div className="catalog-count">{sorted.length} รายการ</div></div><div className="catalog-toolbar"><div className="search-box"><Search size={18} /><input value={query} onChange={e => setQuery(e.target.value)} placeholder="ค้นหาสินค้า..." />{query && <button onClick={() => setQuery("")}><X size={15} /></button>}</div><MobileSelect value={category} onChange={setCategory} /><div className="sort-control"><SlidersHorizontal size={16} /><select value={sort} onChange={e => setSort(e.target.value)}><option value="popular">เรียงตามความนิยม</option><option value="price-low">ราคา: ต่ำไปสูง</option><option value="price-high">ราคา: สูงไปต่ำ</option></select></div></div><div className="catalog-body"><aside className="filter-panel"><div className="filter-title"><b><Filter size={16} /> หมวดหมู่</b></div>{[{ id: "all", label: "สินค้าทั้งหมด" }, { id: "featured", label: "โปรแกรมช่วยเล่น" }, { id: "starter", label: "สำหรับผู้เริ่มต้น" }, { id: "premium", label: "พรีเมียม" }, { id: "license", label: "ใบรับรองดิจิทัล" }, { id: "subscription", label: "สมาชิก" }].map(item => <button className={category === item.id ? "selected" : ""} key={item.id} onClick={() => setCategory(item.id)}>{item.label}<span>{item.id === "all" ? products.length : products.filter(product => product.category === item.id).length}</span></button>)}<div className="filter-note"><ShieldCheck size={18} /><p>ทุกสินค้ามีข้อมูลราคาและสถานะให้ตรวจสอบก่อนสั่งซื้อ</p></div></aside><div className="catalog-grid">{sorted.length ? sorted.map(product => <ProductCard product={product} key={product.id} />) : <div className="empty-state"><Search size={28} /><h3>ไม่พบสินค้าที่ค้นหา</h3><p>ลองเปลี่ยนคำค้นหาหรือเลือกหมวดหมู่อื่น</p></div>}</div></div></div></main><SiteFooter /></div>;
}
