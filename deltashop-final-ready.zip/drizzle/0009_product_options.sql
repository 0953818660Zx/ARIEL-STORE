CREATE TABLE `product_options` (
  `id` int AUTO_INCREMENT NOT NULL,
  `productId` int NOT NULL,
  `label` varchar(120) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int NOT NULL DEFAULT 0,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `product_options_id` PRIMARY KEY(`id`)
);
