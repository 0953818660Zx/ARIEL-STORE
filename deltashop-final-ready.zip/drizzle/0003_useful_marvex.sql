CREATE TABLE `store_settings` (
	`id` int NOT NULL DEFAULT 1,
	`storeName` varchar(180) NOT NULL DEFAULT 'DeltaShop Commerce',
	`logoUrl` text,
	`productImageUrl` text,
	`primaryColor` varchar(16) NOT NULL DEFAULT '#e50918',
	`accentColor` varchar(16) NOT NULL DEFAULT '#ff2636',
	`theme` enum('light','dark') NOT NULL DEFAULT 'dark',
	`snowEnabled` int NOT NULL DEFAULT 0,
	`borderEnabled` int NOT NULL DEFAULT 1,
	`borderColor` varchar(16) NOT NULL DEFAULT '#e50918',
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `store_settings_id` PRIMARY KEY(`id`)
);
