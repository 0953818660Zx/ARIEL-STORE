ALTER TABLE `store_settings` ADD `lineUrl` text;
--> statement-breakpoint
ALTER TABLE `store_settings` ADD `tiktokUrl` text;
--> statement-breakpoint
ALTER TABLE `store_settings` ADD `facebookUrl` text;
--> statement-breakpoint
ALTER TABLE `store_settings` ADD `discordUrl` text;
